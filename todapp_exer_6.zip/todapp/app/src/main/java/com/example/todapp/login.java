package com.example.todapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import static com.example.todapp.R.id.*;

public class login extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Button criar = findViewById(R.id.criar);
        Button entrar = findViewById(R.id.entrar);

        TextView email_cadastro = findViewById(R.id.email_c);
        TextView email_login = findViewById(R.id.email);

        TextView senha_cadastro = findViewById(R.id.senha_c);
        TextView senha_login = findViewById(R.id.senha);


        //vai chamar a outra tela quando clicar no button

        criar.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent it = new Intent(MainActivity.this, Criar.class);
                startActivity(it);
            }
        });

        //verificar se o login pelo cadastro / ENTRAR

        if(email_cadastro == email_login){
            if(senha_cadastro == senha_login){
                entrar.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        Intent it = new Intent(MainActivity.this, MainActivity.class);
                        startActivity(it);
                    }
                });
            }
        }
        else{

        }

    }
}
